<?php namespace y;

class SampleComponent {

    public function sayHello() {
        return 'Helloooo';
    }


}

?>

<?php 

class SampleComponent {

    public function sayHello() {
        return 'Helloooo';
    }


}

?>

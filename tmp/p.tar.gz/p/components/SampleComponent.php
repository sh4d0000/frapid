<?php use p;

class SampleComponent {

    public function sayHello() {
        return 'Helloooo';
    }


}

?>

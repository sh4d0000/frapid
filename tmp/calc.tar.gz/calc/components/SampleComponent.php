<?php namespace calc;

class SampleComponent {

  /**
   * This is an hello world method.
   *
   * @author user <user@user.com>
   *
   * @param string $name This is a second example.
   *
   * @frapid-url /hello
   * @frapid-method get
   *
   */
  public function sayHello( $name ) {
    return "Hello $name";
  }


}

?>
